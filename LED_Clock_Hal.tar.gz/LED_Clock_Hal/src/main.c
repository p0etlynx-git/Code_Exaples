/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "rtc.h"
#include "usart.h"
#include "gpio.h"
 

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
//#include "tm1637.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void IntToStr(char *str,int value);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void TestAI(void){
  printf("Hello");printf("")
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  uint8_t my_usart_buf[100] = " \0";
  uint32_t buf_len = 0;

  RTC_TimeTypeDef sTime = {0};
  RTC_DateTypeDef DateToUpdate = {0};

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  // Настройка USART2
  MX_USART2_UART_Init();  

  // перевести курсор терминала на 1 строку и 1 символ
  // отчистить область вывода нашей информации
  buf_len = snprintf( (char *)my_usart_buf, 99, "\033[H                                                   \r\n");
  HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 10);
  buf_len = snprintf( (char *)my_usart_buf, 99, "                                                   \r\n");
  HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 10);
  buf_len = snprintf( (char *)my_usart_buf, 99, "                                                   \r\n");
  HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 10);
  buf_len = snprintf( (char *)my_usart_buf, 99, "                                                   \r\n");
  HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 10);
  buf_len = snprintf( (char *)my_usart_buf, 99, "                                                   \r\n");
  HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 10);
  buf_len = snprintf( (char *)my_usart_buf, 99, "                                                   \r\n");
  HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 10);

  // перевести курсор терминала на 1 строку и 1 символ
  // и начать выводить данные программы на терминал
  buf_len = snprintf( (char *)my_usart_buf, 99, "\033[H\r\nНачало работы...     \r\n");
  HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 10);

  buf_len = snprintf( (char *)my_usart_buf, 99, "USART2 настроен...      \r\n");
  HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 10);

  MX_GPIO_Init(); // Настройка GPIO
  buf_len = snprintf( (char *)my_usart_buf, 99, "GPIO настроен...      \r\n");
  HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 10);

  MX_RTC_Init();  // Настройка RTC
  HAL_RTCEx_SetSecond_IT(&hrtc);  // Включить глобальное прерывание RTC
  buf_len = snprintf( (char *)my_usart_buf, 99, "RTC настроен...     \r\n");
  HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 10);

  // выведем на терминал текущее время и дату RTC STM32
  HAL_RTC_GetTime( &hrtc, &sTime, RTC_FORMAT_BIN);
  buf_len = snprintf( (char *)my_usart_buf, 99, "RTC Time %d:%d:%d\r\n", sTime.Hours, sTime.Minutes, sTime.Seconds);
  HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 10);

  HAL_RTC_GetDate(&hrtc, &DateToUpdate, RTC_FORMAT_BIN);
  buf_len = snprintf( (char *)my_usart_buf, 99, "RTC Date %d-%d-20%d\r\n", DateToUpdate.Date, DateToUpdate.Month, DateToUpdate.Year);
  HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 10);


  // проверить скорость выполнения функции snprintf с форматированием и преобразованием числа в строку
  // посчитать  время выполнения в системных тиках, перевести в мили секунды, вывести на терминал
  buf_len = snprintf( (char *)my_usart_buf, 99, "тест sprintf [----------] \033[12D");
  HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 10);

  DWT->CTRL |= 1 ; // включение счетчика
  DWT->CYCCNT = 0; // сброс счетчика  
  
  // Начальное время
  uint32_t start = DWT->CYCCNT;
  
  //тестовая функция
  for(uint32_t i = 0; i < 10; i++)
  {
    for(uint32_t j = 0; j < 20000; j++)
    {
      buf_len = sprintf( (char *)my_usart_buf, "%4d", 2468);
    }
    buf_len = snprintf( (char *)my_usart_buf, 99, "O");
    HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 1);
  }
  // конечное время
  uint32_t end = DWT->CYCCNT;
  // прошло времени
  end = (end - start) / 8000;

  buf_len = snprintf( (char *)my_usart_buf, 99, "\033[1C %ld мл секунд\r\n", end);
  HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 10);


  // проверить скорость выполнения функции sprintf с форматированием и преобразованием числа в строку
  // посчитать  время выполнения в системных тиках, перевести в мили секунды, вывести на терминал
  buf_len = snprintf( (char *)my_usart_buf, 99, "тест snprintf [----------] \033[12D");
  HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 10);
  DWT->CYCCNT = 0; // сброс счетчика  
  start = DWT->CYCCNT;

  for(uint32_t i = 0; i < 10; i++)
  {
    for(uint32_t j = 0; j < 20000; j++)
    {
      buf_len = snprintf( (char *)my_usart_buf, 99, "%4d", 2468);
    }
    buf_len = snprintf( (char *)my_usart_buf, 99, "O");
    HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 1);
  }
  end = DWT->CYCCNT;
  end = (end - start) / 8000;

  buf_len = snprintf( (char *)my_usart_buf, 99, "\033[1C %ld мл секунд\r\n", end);
  HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 10);

  // проверить скорость выполнения функции sprintf с форматированием, без преобразования числа в строку
  // посчитать  время выполнения в системных тиках, перевести в мили секунды, вывести на терминал
  buf_len = snprintf( (char *)my_usart_buf, 99, "тест sprintf [----------] \033[12D");
  HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 10);
  DWT->CYCCNT = 0; // сброс счетчика  
  start = DWT->CYCCNT;

  for(uint32_t i = 0; i < 10; i++)
  {
    for(uint32_t j = 0; j < 20000; j++)
    {
      buf_len = snprintf( (char *)my_usart_buf, 99, "2468");
    }
    buf_len = snprintf( (char *)my_usart_buf, 99, "O");
    HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 1);
  }
  end = DWT->CYCCNT;
  end = (end - start) / 8000;

  buf_len = snprintf( (char *)my_usart_buf, 99, "\033[1C %ld мл секунд\r\n", end);
  HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 10);
  
  // проверить скорость выполнения функции прямой записи числа в строку с форматированием вправо.
  // посчитать  время выполнения в системных тиках, перевести в мили секунды, вывести на терминал
  buf_len = snprintf( (char *)my_usart_buf, 99, "тест своей функции [----------] \033[12D");
  HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 10);
  DWT->CYCCNT = 0; // сброс счетчика  
  start = DWT->CYCCNT;

  for(uint32_t i = 0; i < 10; i++)
  {
    for(uint32_t j = 0; j < 20000; j++)
    {
      IntToStr( (char *)my_usart_buf, 287);
    }
    buf_len = snprintf( (char *)my_usart_buf, 99, "O");
    HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 1);
  }
  end = DWT->CYCCNT;
  end = (end - start) / 8000;

  buf_len = snprintf( (char *)my_usart_buf, 99, "\033[1C %ld мл секунд\r\n", end);
  HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 10);
  
  // выведем на терминал текущее время и дату RTC STM32
  HAL_RTC_GetTime( &hrtc, &sTime, RTC_FORMAT_BIN);
  buf_len = snprintf( (char *)my_usart_buf, 99, "RTC Time %d:%d:%d\r\n", sTime.Hours, sTime.Minutes, sTime.Seconds);
  HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 10);

  HAL_RTC_GetDate(&hrtc, &DateToUpdate, RTC_FORMAT_BIN);
  buf_len = snprintf( (char *)my_usart_buf, 99, "RTC Date %d-%d-20%d\r\n", DateToUpdate.Date, DateToUpdate.Month, DateToUpdate.Year);
  HAL_UART_Transmit( &huart2, my_usart_buf, buf_len, 10);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_LSE;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_RTC;
  PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSE;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void IntToStr( char *str, int value) {
    str[0] = (uint8_t)value / 1000;    // количесто тысяч в числе
    uint16_t b = (int)str[0] * 1000; 	// вспомогательная переменная
    str[1] = ((int)value - b) / 100; 	// получем количество сотен
    b += str[1] * 100;               	// суммируем сотни и тысячи
    str[2] = (int)(value - b) / 10;  	// получем десятки
    b += str[2] * 10;                	// сумма тысяч, сотен и десятков
    str[3] = value - b;
    str[4] = 0;
    for(uint8_t i =0; i < 4; i++)
    {
      str[i]+=48;
    }
    for(uint8_t i =0; i < 4; i++)
    {
      if(str[i]!=48) break;
      str[i]=32;
    }
}

// Глобальное прерывание от RTC раз в секунду
void HAL_RTCEx_RTCEventCallback(RTC_HandleTypeDef *hrtc)
{
  // мигаем светодиодом
  HAL_GPIO_TogglePin( LD2_GPIO_Port, LD2_Pin);
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
