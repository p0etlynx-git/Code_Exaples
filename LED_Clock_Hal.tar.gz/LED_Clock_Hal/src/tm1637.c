/*
 * tm1637.c
 *
 *  Created on: 29 сент. 2019 г.
 *      Author: dima
 */

//#include "delay_micros.h"
#include "tm1637.h"

// Таблица кодов символов светодиодного индикатора
const uint8_t digitHEX[] = {0x3f, 0x06, 0x5b, 0x4f, // '0', '1', '2', '3'
    						0x66, 0x6d, 0x7d, 0x07,	// '4', '5', '6', '7'
    						0x7f, 0x6f, 0x00, 0x40  // '8', '9', ' ', '-'
};

TM1637_Data htm1637 = {0};

void HAL_TM1637_Write( TM1637_Data *htm1637, uint8_t position, uint8_t number)
{

}

// подготовка структуры тм1637 начальными данными
void HAL_TM1637_Init( TM1637_Data *htm1637)
{
	htm1637->A = 0; // нет цифры
	htm1637->B = 0; // нет цифры
	htm1637->C = 0; // нет цифры
	htm1637->D = 0; // нет цифры
	htm1637->Brightness = 0x88 + 2;	// яркость от 0 до 7
	htm1637->Colon = 0;			    //
	for(uint8_t i = 0; i < 56; i++)	// обнуляем битовый буфер 
	{
		htm1637->bitmask[i] = 0;
	}
	htm1637->bitmask[6] = 1; 	// [0..07] Command1 - Set data: Write SRAM data in address auto increment 1 mode
	htm1637->bitmask[14] = 1;	// [8..15] Command2 - Set address: Display address C0H
	htm1637->bitmask[15] = 1;
								// [16..23] - C0H символ
								// [24..31] - C1H символ
								// [32..39] - C2H символ
								// [40..47] - C3H символ
	for(uint8_t i = 48, j = 0x88 + htm1637->Brightness; i < 56; i++)// [48..55] - Command3: Control display (Display ON | Brightnes 2)
	{
		htm1637->bitmask[i] = j & 0x01;
		j = j >> 1;
	}
}

// Конвентируем номер цифры в код светодиодного индикатора
uint8_t digToHEX(uint8_t digit) {
    return digitHEX[digit];
}

// Отправляем последовательность сигналов по даташиту
// Начало отправки байта
void tm1637_start(void)
{
	HAL_GPIO_WritePin(TM1637_PORT_Clk, TM1637_PIN_Clk, GPIO_PIN_SET);
	HAL_GPIO_WritePin(TM1637_PORT_Data, TM1637_PIN_Data, GPIO_PIN_SET);
	HAL_Delay(1);
	HAL_GPIO_WritePin(TM1637_PORT_Data, TM1637_PIN_Data, GPIO_PIN_RESET);
	HAL_Delay(1);
	HAL_GPIO_WritePin(TM1637_PORT_Clk, TM1637_PIN_Clk, GPIO_PIN_RESET);
}

// Отправляем последовательность сигналов по даташиту
// Окончание отправки байта
void tm1637_stop(void)
{
	HAL_GPIO_WritePin(TM1637_PORT_Clk, TM1637_PIN_Clk, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(TM1637_PORT_Data, TM1637_PIN_Data, GPIO_PIN_RESET);
	HAL_Delay(1);
	HAL_GPIO_WritePin(TM1637_PORT_Clk, TM1637_PIN_Clk, GPIO_PIN_SET);
	HAL_Delay(1);
	HAL_GPIO_WritePin(TM1637_PORT_Data, TM1637_PIN_Data, GPIO_PIN_SET);
}

// Отправляем последовательность бит из байта
// ожидаем ответа от драйвера, об окончании приёма
void writeByte(int8_t wr_data)
{
    uint8_t i, count1;
    for (i = 0; i < 8; i++) //sent 8bit data
    {
        digitalWrite(Clkpin, LOW);
        if (wr_data & 0x01)digitalWrite(Datapin, HIGH); //LSB first
        else digitalWrite(Datapin, LOW);
        wr_data >>= 1;
        digitalWrite(Clkpin, HIGH);

    }
    digitalWrite(Clkpin, LOW); //wait for the ACK
    digitalWrite(Datapin, HIGH);
    digitalWrite(Clkpin, HIGH);
    pinMode(Datapin, INPUT);

    delayMicroseconds(50);
    uint8_t ack = digitalRead(Datapin);
    if (ack == 0)
    {
        pinMode(Datapin, OUTPUT);
        digitalWrite(Datapin, LOW);
    }
    delayMicroseconds(50);
    pinMode(Datapin, OUTPUT);
    delayMicroseconds(50);

    return ack;
}
/*
void HAL_TM1637_Init(TM1637_Data *htm1637)
{
	uint8_t bitpointer = 31;
	uint8_t byte = 0b10001111; // display = ON, Brightnes = 7
	for(uint8_t i = 0; i < 8; i++, bitpointer--)
	{
		htm1637->bitmask[bitpointer] = byte & 0b00000001;
		byte >>= 1;
	}
	byte = TubeTab[htm1637->D];

	htm1637->A = 0;
	htm1637->B = 0;
	htm1637->C = 0;
	htm1637->D = 0;
	htm1637->Brightness = 0;
	htm1637->Colon = 0;



	display(0x00, 0x7f);
	display(0x01, 0x7f);
	display(0x02, 0x7f);
	display(0x03, 0x7f);
}

void HAL_TM1637_Display(TM1637_Data *htm1637)
{
	uint8_t bitmask[56];
	uint8_t bitpointer = 31;

}

uint8_t Cmd_DispCtrl = 0;
uint8_t point_flag = 0;

static int8_t TubeTab[] = {0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f, 0x77,0x7c,0x40}; //0~9, A(10), b(11), -(12)

void writeByte(int8_t wr_data)
{
  uint8_t count = 0;

  for(uint8_t i = 0; i < 8; i++)
  {
    CLK_LOW;

    if(wr_data & 0x01) DIO_HIGH;
    else DIO_LOW;

//    delay_micros(6);
    HAL_Delay(1);
    wr_data >>= 1;
    HAL_Delay(1);
//    delay_micros(6);
    CLK_HIGH;
    HAL_Delay(1);
//    delay_micros(8);
  }

  CLK_LOW;
//  delay_micros(6);
    HAL_Delay(1);
  DIO_HIGH;
//  delay_micros(6);
    HAL_Delay(1);
  CLK_HIGH;
    HAL_Delay(1);
//  delay_micros(8);

  while(DIO_READ)
  {
    count += 1;

    if(count == 200)
    {
    	DIO_LOW;
    	count = 0;
    }
  }
}

void start(void)
{
	CLK_HIGH;
    HAL_Delay(1);
//	delay_micros(6);
	DIO_HIGH;
    HAL_Delay(1);
//	delay_micros(6);
	DIO_LOW;
    HAL_Delay(1);
//	delay_micros(6);
	CLK_LOW;
}

void stop(void)
{
	CLK_LOW;
    HAL_Delay(1);
//	delay_micros(6);
	DIO_LOW;
    HAL_Delay(1);
//	delay_micros(6);
	CLK_HIGH;
    HAL_Delay(1);
//	delay_micros(6);
	DIO_HIGH;
}

void display_mass(int8_t DispData[])
{
	int8_t SegData[4];

	for(uint8_t i = 0; i < 4; i++)
	{
		SegData[i] = DispData[i];
	}

	coding_mass(SegData);
	start();
	writeByte(ADDR_AUTO);
	stop();
	start();
	writeByte(0xc0);

	for(uint8_t i = 0; i < 4; i++)
	{
		writeByte(SegData[i]);
	}

	stop();
	start();
	writeByte(Cmd_DispCtrl);
	stop();
}

void display(uint8_t BitAddr, int8_t DispData)
{
	int8_t SegData;

	SegData = coding(DispData);
	start();
	writeByte(ADDR_FIXED);

	stop();
	start();
	writeByte(BitAddr | 0xc0);

	writeByte(SegData);
	stop();
	start();

	writeByte(Cmd_DispCtrl);
	stop();
}

void clearDisplay(void)
{
	display(0x00, 0x7f);
	display(0x01, 0x7f);
	display(0x02, 0x7f);
	display(0x03, 0x7f);
}

void set_brightness(uint8_t brightness)
{
	Cmd_DispCtrl = 0x88 + brightness;
}

void point(uint8_t cmd)
{
	if(cmd == 0) point_flag = (~point_flag) & 0x01;
	else point_flag = 1;
}

void coding_mass(int8_t DispData[])
{
	uint8_t PointData;

	if(point_flag == 1) PointData = 0x80;
	else PointData = 0;

	for(uint8_t i = 0; i < 4; i++)
	{
		if(DispData[i] == 0x7f) DispData[i] = 0x00;
		else DispData[i] = TubeTab[DispData[i]] + PointData;
	}
}

int8_t coding(int8_t DispData)
{
	uint8_t PointData;

	if(point_flag == 1) PointData = 0x80;
	else PointData = 0;

	if(DispData == 0x7f) DispData = 0x00 + PointData;
	else DispData = TubeTab[DispData] + PointData;

	return DispData;
} 
*/